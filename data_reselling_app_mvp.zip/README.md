# DataHub — Data Reselling App MVP

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`
4. Copy `.env.example` to `.env` and set a strong JWT secret.
5. Run `npm start`
6. Open http://localhost:3000

## Included
- User registration/login with JWT
- Password hashing with bcrypt
- Wallet balance
- Demo wallet funding endpoint
- Data plan catalogue
- Data purchase endpoint
- Transaction history
- Responsive browser UI
- Placeholder VTU API integration point
- Environment-variable configuration

## Production next steps
- PostgreSQL database + migrations
- Paystack/Flutterwave payment initialization and webhook verification
- Connect a real VTU/data API
- Never trust client prices; retrieve prices server-side
- Idempotency keys for wallet funding and purchases
- Provider transaction-status polling/webhooks
- Admin roles/dashboard
- Rate limiting, validation, audit logs and HTTPS
- Secure secrets management
