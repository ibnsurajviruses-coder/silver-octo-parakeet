
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_IN_PRODUCTION";

// Demo in-memory storage. Replace with PostgreSQL/MySQL in production.
const users = [];
const transactions = [];

const plans = [
  { id:"mtn-1gb", network:"MTN", size:"1GB", validity:"30 days", price:350 },
  { id:"mtn-2gb", network:"MTN", size:"2GB", validity:"30 days", price:700 },
  { id:"mtn-5gb", network:"MTN", size:"5GB", validity:"30 days", price:1600 },
  { id:"glo-1gb", network:"Glo", size:"1GB", validity:"30 days", price:330 },
  { id:"airtel-1gb", network:"Airtel", size:"1GB", validity:"30 days", price:350 },
  { id:"9mobile-1gb", network:"9mobile", size:"1GB", validity:"30 days", price:300 }
];

function auth(req,res,next){
  const token = (req.headers.authorization || "").replace("Bearer ","");
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({message:"Unauthorized"}); }
}

app.post("/api/auth/register", async (req,res)=>{
  const {name,email,password} = req.body;
  if(!name || !email || !password) return res.status(400).json({message:"All fields are required"});
  if(users.some(u=>u.email.toLowerCase()===email.toLowerCase()))
    return res.status(409).json({message:"Email already registered"});
  const passwordHash = await bcrypt.hash(password,10);
  const user = {id:String(users.length+1),name,email:email.toLowerCase(),passwordHash,balance:0};
  users.push(user);
  const token = jwt.sign({id:user.id,email:user.email},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,balance:user.balance}});
});

app.post("/api/auth/login", async (req,res)=>{
  const {email,password} = req.body;
  const user = users.find(u=>u.email===String(email).toLowerCase());
  if(!user || !(await bcrypt.compare(password,user.passwordHash)))
    return res.status(401).json({message:"Invalid email or password"});
  const token = jwt.sign({id:user.id,email:user.email},JWT_SECRET,{expiresIn:"7d"});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,balance:user.balance}});
});

app.get("/api/plans",(req,res)=>res.json(plans));

app.get("/api/me",auth,(req,res)=>{
  const u = users.find(x=>x.id===req.user.id);
  res.json({id:u.id,name:u.name,email:u.email,balance:u.balance});
});

app.get("/api/transactions",auth,(req,res)=>{
  res.json(transactions.filter(t=>t.userId===req.user.id).reverse());
});

app.post("/api/wallet/fund",auth,(req,res)=>{
  const amount = Number(req.body.amount);
  if(!Number.isFinite(amount) || amount < 100) return res.status(400).json({message:"Minimum funding is ₦100"});
  // DEMO ONLY: real app should create a payment transaction with Paystack/Flutterwave.
  const u = users.find(x=>x.id===req.user.id);
  u.balance += amount;
  const tx = {id:"TX"+Date.now(),userId:u.id,type:"wallet_funding",amount,status:"successful",description:"Demo wallet funding",createdAt:new Date().toISOString()};
  transactions.push(tx);
  res.json({message:"Wallet funded (demo)",balance:u.balance,transaction:tx});
});

app.post("/api/purchase/data",auth,async (req,res)=>{
  const {planId,phone} = req.body;
  const plan = plans.find(p=>p.id===planId);
  const u = users.find(x=>x.id===req.user.id);
  if(!plan) return res.status(404).json({message:"Plan not found"});
  if(!/^0\d{10}$/.test(String(phone))) return res.status(400).json({message:"Enter a valid Nigerian phone number"});
  if(u.balance < plan.price) return res.status(400).json({message:"Insufficient wallet balance"});

  // Replace this section with your VTU provider API call.
  // Example shape:
  // await fetch(process.env.VTU_API_URL, {headers:{Authorization:`Bearer ${process.env.VTU_API_KEY}`}, ...})

  u.balance -= plan.price;
  const tx = {
    id:"TX"+Date.now(), userId:u.id, type:"data_purchase", amount:plan.price,
    status:"successful", phone, plan:`${plan.network} ${plan.size}`,
    description:`${plan.network} ${plan.size} data`,
    createdAt:new Date().toISOString()
  };
  transactions.push(tx);
  res.json({message:"Data purchase successful (demo)",balance:u.balance,transaction:tx});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`Data Reselling App running on http://localhost:${PORT}`));
